<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'basedatosebus');

/** MySQL database username */
define('DB_USER', 'root');

/** MySQL database password */
define('DB_PASSWORD', '');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8mb4');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         '=2t3}`mFRjgm9qr}H+?A-``rAk;M^PI5|`|3<wQ{P(3&nj<[!&./[ttWN5a%`R8k');
define('SECURE_AUTH_KEY',  'nC lRo6oucwHN=#P}U2ti+1gJ$ahxVDFkT4Kt!qAXY8nIIu|qzZFvY+7&>~%C+1e');
define('LOGGED_IN_KEY',    '<k@GkFu#A9>(:N;vr5P8NXMTFu,Qg}qpuPN-.[X.~)u*;5Pc3by^!O(]E^~M2;H&');
define('NONCE_KEY',        ']IJW?D=1X!=DG9qXw?xbHun(!XO+$iR7pDd* 3e=lw/U3Gc.gf%21@aMdk8zJaoq');
define('AUTH_SALT',        '=Or/[86]j,EKnW[8{,i>i`^awvSaNqab<1|T~Jvae;Kh;Bq}l/%6B~.~=&X/7XX7');
define('SECURE_AUTH_SALT', 'Y3s~1sT>TcF7X9_5-{3h;FWwhBT}h+2cp7|bSye6dy;X*Ilw-^FtF`/[`,Xonh7a');
define('LOGGED_IN_SALT',   '&gm/(G(:1C`qVr_r~HnmE)^PYfP<06$M*=j) +DY0pJe5=#7Lu#5~7)V$]-,}9%E');
define('NONCE_SALT',       '+$0^7nF8UH@&gO@Xx85LknrX,n;W2vFrJl71V|0vCEe4MX<Dp(TG+HI$!m:7Z(8R');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
